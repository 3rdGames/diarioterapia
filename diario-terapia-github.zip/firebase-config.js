// Cole aqui os dados do seu projeto Firebase (Configurações do projeto > Seus apps > Web).
// Esses dados são públicos por natureza; a segurança vem das regras do Firestore (firestore.rules).
export const firebaseConfig = {
  apiKey: 'COLE_AQUI',
  authDomain: 'COLE_AQUI',
  projectId: 'COLE_AQUI',
  storageBucket: 'COLE_AQUI',
  messagingSenderId: 'COLE_AQUI',
  appId: 'COLE_AQUI'
};
